package com.hex.mycareerCrafter.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.Converter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.payload.ApplicationDTO;
import com.hex.mycareerCrafter.payload.JobDTO;
import com.hex.mycareerCrafter.models.ApplicationStatus;

@Configuration
public class AppConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

        // Custom mapping for Job to JobDTO
        modelMapper.addMappings(new PropertyMap<Job, JobDTO>() {
            @Override
            protected void configure() {
                map().setEmployerId(source.getEmployer().getId()); // Only map the employerId
            }
        });

        // Custom mapping for Application to ApplicationDTO
        modelMapper.addMappings(new PropertyMap<Application, ApplicationDTO>() {
            @Override
            protected void configure() {
                map().setJobId(source.getJob().getJobId()); // Assuming Job has a getJobId() method
                map().setJobSeekerId(source.getJobSeeker().getJobSeekerId()); // Assuming JobSeeker has a getJobSeekerId() method
                // Removed the direct mapping for status
            }
        });

        // Custom converter for ApplicationStatus to String
        Converter<ApplicationStatus, String> statusToStringConverter = ctx -> ctx.getSource() == null ? null : ctx.getSource().name();
        modelMapper.addConverter(statusToStringConverter, ApplicationStatus.class, String.class);

        return modelMapper;
    }
}
