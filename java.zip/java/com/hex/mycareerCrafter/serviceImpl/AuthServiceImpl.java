package com.hex.mycareerCrafter.serviceImpl;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hex.mycareerCrafter.models.Employer;
import com.hex.mycareerCrafter.models.JobSeeker;
import com.hex.mycareerCrafter.models.User;
import com.hex.mycareerCrafter.payload.JwtAuthResponse;
import com.hex.mycareerCrafter.payload.LoginDTO;
import com.hex.mycareerCrafter.payload.RegisterDTO;
import com.hex.mycareerCrafter.repository.UserRepository;
import com.hex.mycareerCrafter.security.JwtTokenProvider;
import com.hex.mycareerCrafter.service.AuthService;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private AuthenticationManager authenticationManager;

    
    @Override
    public JwtAuthResponse login(LoginDTO loginDTO) {
        // Step 1: Fetch the user by email
        User user = userRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));

        // Step 2: Validate the role from the loginDTO against the user's registered role
        if ("EMPLOYER".equalsIgnoreCase(loginDTO.getUserType()) && !(user instanceof Employer)) {
            throw new IllegalArgumentException("Invalid role: The user is not registered as an Employer.");
        } else if ("JOB_SEEKER".equalsIgnoreCase(loginDTO.getUserType()) && !(user instanceof JobSeeker)) {
            throw new IllegalArgumentException("Invalid role: The user is not registered as a Job Seeker.");
        }

        // Step 3: Proceed with authentication if role is valid
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginDTO.getEmail(), loginDTO.getPassword()));

        // Step 4: Generate JWT token
        String token = jwtTokenProvider.generateToken(authentication);

        // Step 5: Create JwtAuthResponse with user IDs
        Long employerId = null;
        Long seekerId = null;

        if (user instanceof Employer) {
            employerId = user.getId(); // Assuming employer ID is the same as the user ID
        } else if (user instanceof JobSeeker) {
            seekerId = ((JobSeeker) user).getSeekerId(); // Get the seeker ID
        }

        return new JwtAuthResponse(token, employerId, seekerId);
    }


    @Override
    public void register(RegisterDTO registerDTO) {
        User user;

        // Create the user object based on the userType
        if ("EMPLOYER".equalsIgnoreCase(registerDTO.getUserType())) {
            user = new Employer();
            ((Employer) user).setCompanyName(registerDTO.getCompanyName());
        } else if ("JOB_SEEKER".equalsIgnoreCase(registerDTO.getUserType())) {
            user = new JobSeeker();
            ((JobSeeker) user).setQualification(registerDTO.getQualification());
        } else {
            throw new IllegalArgumentException("Invalid user type provided");
        }

        // Set common user fields
        user.setName(registerDTO.getName());
        user.setEmail(registerDTO.getEmail());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setPhoneNumber(registerDTO.getPhoneNumber());

        // Save the user without setting employerId/seekerId to generate the ID
        User savedUser = userRepository.save(user);

        // Set employerId or seekerId based on generated ID
        if (savedUser instanceof Employer) {
            ((Employer) savedUser).setId( savedUser.getId());
        } else if (savedUser instanceof JobSeeker) {
            ((JobSeeker) savedUser).setSeekerId( savedUser.getId());
        }

        // Save again with the updated employerId or seekerId
        userRepository.save(savedUser);
    }
}
