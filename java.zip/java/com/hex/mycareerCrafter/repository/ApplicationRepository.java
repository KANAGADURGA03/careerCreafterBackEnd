package com.hex.mycareerCrafter.repository;
import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.JobSeeker;
import com.hex.mycareerCrafter.models.Employer;
import com.hex.mycareerCrafter.models.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByJobSeeker(JobSeeker jobSeeker);

    List<Application> findByJob(Job job);

    List<Application> findByEmployer(Employer employer);
//    List<Application> findByEmployer(Employer employer);
    
        List<Application> findByJobSeekerId(Long jobSeekerId);
    

    // Additional query methods can be added here if needed
}