package com.hex.mycareerCrafter.repository;
import com.hex.mycareerCrafter.models.Employer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployerRepository extends JpaRepository<Employer, Long> {
    // Example of a custom query method
    Optional<Employer> findByEmail(String email);
    
    // Additional query methods for Employer entity can be defined here
}