package com.hex.mycareerCrafter.repository;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.models.Employer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByEmployer(Employer employer);

    List<Job> findByTitleContainingIgnoreCase(String title);
    //List<Job> findByJobSeekersId(Long jobSeekerId);

    // Additional query methods can be added here if needed
}