package com.hex.mycareerCrafter.repository;
import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.JobSeeker;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JobSeekerRepository extends JpaRepository<JobSeeker, Long> {
    // You can define custom query methods here if needed
}
