/*
 * package com.hex.mycareerCrafter.utils; public class AppConstants { public
 * static final String JWT_SECRET = "your-secret-key"; // Example value public
 * static final int JWT_EXPIRATION_MS = 86400000; // Example value for 1 day in
 * milliseconds public static final String AUTH_HEADER = "Authorization"; // Add
 * other constants as needed }
 */