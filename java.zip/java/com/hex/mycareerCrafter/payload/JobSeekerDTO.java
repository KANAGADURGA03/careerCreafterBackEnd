package com.hex.mycareerCrafter.payload;

import java.util.List;

import com.hex.mycareerCrafter.models.Job;

public class JobSeekerDTO extends UserDTO {
    private Long seekerId;
    private String qualification;
   

    public Long getSeekerId() {
        return seekerId;
    }

    public void setSeekerId(Long seekerId) {
        this.seekerId = seekerId;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

}
