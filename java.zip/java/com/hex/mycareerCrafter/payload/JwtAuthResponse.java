package com.hex.mycareerCrafter.payload;

public class JwtAuthResponse {
    private String accessToken;
    private Long employerId;
    private Long seekerId;
    private String tokenType = "Bearer";

    public JwtAuthResponse(String accessToken, Long employerId, Long seekerId) {
        this.accessToken = accessToken;
        this.employerId = employerId;
        this.seekerId = seekerId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Long getEmployerId() {
        return employerId;
    }

    public void setEmployerId(Long employerId) {
        this.employerId = employerId;
    }

    public Long getSeekerId() {
        return seekerId;
    }

    public void setSeekerId(Long seekerId) {
        this.seekerId = seekerId;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }
}
