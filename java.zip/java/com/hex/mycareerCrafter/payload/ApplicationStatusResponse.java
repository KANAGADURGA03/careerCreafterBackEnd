package com.hex.mycareerCrafter.payload;

public class ApplicationStatusResponse {
	private Long jobId;
	
    public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	private Long applicationId;
    private String status;

    // Constructors
    public ApplicationStatusResponse() {}

    public ApplicationStatusResponse(Long applicationId, String status, Long jobId) {
        this.applicationId = applicationId;
        this.status = status;
        this.jobId = jobId;
        
    }

    // Getters and setters
    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
