package com.hex.mycareerCrafter.payload;

public class ApplicationResponse {
    private Long applicationId;
    private String message;

    // Constructor
    public ApplicationResponse(Long applicationId, String message) {
        this.applicationId = applicationId;
        this.message = message;
    }

    // Getters and Setters
    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
