package com.hex.mycareerCrafter.payload;
import java.time.LocalDateTime;

public class ApplicationDTO {
    private Long applicationId;
    private Long jobId;
    private Long jobSeekerId;
    private byte[] resume;
    private String status;
    private LocalDateTime date;
    private String qualification;
    private Double twelfthPercentage;
    private Long employerId; // Represent employer with their ID
	public Long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	public Long getJobId() {
		return jobId;
	}
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}
	public Long getJobSeekerId() {
		return jobSeekerId;
	}
	public void setJobSeekerId(Long jobSeekerId) {
		this.jobSeekerId = jobSeekerId;
	}

	public byte[] getResume() {
		return resume;
	}
	public void setResume(byte[] resume) {
		this.resume = resume;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public Long getEmployerId() {
		return employerId;
	}
	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}
	 public String getQualification() {
	        return qualification;
	    }

	    public void setQualification(String qualification) {
	        this.qualification = qualification;
	    }
	    public Double getTwelfthPercentage() {
	        return twelfthPercentage;
	    }

	    public void setTwelfthPercentage(Double twelfthPercentage) {
	        this.twelfthPercentage = twelfthPercentage;
	    }
		
		

  
}