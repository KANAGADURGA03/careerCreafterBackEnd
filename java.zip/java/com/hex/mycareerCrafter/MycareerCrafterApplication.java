package com.hex.mycareerCrafter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MycareerCrafterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MycareerCrafterApplication.class, args);
	}

}
