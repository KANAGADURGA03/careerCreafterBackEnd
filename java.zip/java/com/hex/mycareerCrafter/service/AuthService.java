package com.hex.mycareerCrafter.service;

import com.hex.mycareerCrafter.payload.LoginDTO;
import com.hex.mycareerCrafter.payload.RegisterDTO;
import com.hex.mycareerCrafter.payload.JwtAuthResponse;

public interface AuthService {
    JwtAuthResponse login(LoginDTO loginDTO);
    void register(RegisterDTO registerDTO);
}
