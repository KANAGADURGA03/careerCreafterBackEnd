package com.hex.mycareerCrafter.service;

import java.util.List;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hex.mycareerCrafter.exceptions.InvalidApplicationException;
import com.hex.mycareerCrafter.exceptions.JobNotFoundException;
import com.hex.mycareerCrafter.exceptions.UserNotFoundException;

import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.ApplicationStatus;
import com.hex.mycareerCrafter.models.Employer;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.payload.EmployerDTO;
import com.hex.mycareerCrafter.repository.ApplicationRepository;
import com.hex.mycareerCrafter.repository.EmployerRepository;
import com.hex.mycareerCrafter.repository.JobRepository;


@Service
@Transactional
public class EmployerService {

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ModelMapper modelMapper;

    // Employer methods

    // Create Employer
    public Employer createEmployer(EmployerDTO employerDTO) {
        Employer employer = modelMapper.map(employerDTO, Employer.class);
        return employerRepository.save(employer);
    }

    // Update Employer
    public Employer updateEmployer(Long id, EmployerDTO employerDTO) {
        Employer employer = employerRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Employer not found with id: " + id));

        modelMapper.map(employerDTO, employer);
        return employerRepository.save(employer);
    }

    // Delete Employer
    public void deleteEmployer(Long id) {
        Employer employer = employerRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Employer not found with id: " + id));
        employerRepository.delete(employer);
    }
    //get employer by id
    public Employer getEmployerById(Long employerId) {
        return employerRepository.findById(employerId)
                .orElseThrow(() -> new IllegalArgumentException("Employer not found with ID: " + employerId));
    }

    // Get Jobs by Employer
    public List<Job> getJobsByEmployer(Long employerId) {
        Employer employer = employerRepository.findById(employerId)
                .orElseThrow(() -> new UserNotFoundException("Employer not found with id: " + employerId));

        return jobRepository.findByEmployer(employer);
    }

    // Job methods

    public Job createJob(Long employerId, Job job) {
        Employer employer = employerRepository.findById(employerId)
                .orElseThrow(() -> new UserNotFoundException("Employer not found with id: " + employerId));

        job.setEmployer(employer);  // Associate the job with the employer
        return jobRepository.save(job);
    }

    public Job updateJob(Long jobId, Job jobDetails) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new JobNotFoundException("Job not found with id: " + jobId));

        job.setTitle(jobDetails.getTitle());
        job.setDescription(jobDetails.getDescription());
        job.setQualification(jobDetails.getQualification());

        return jobRepository.save(job);
    }

    public void deleteJob(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new JobNotFoundException("Job not found with id: " + jobId));
        jobRepository.delete(job);
    }

    // Application methods
    public List<Application> getApplicationsByEmployerId(Long employerId) {
        Employer employer = employerRepository.findById(employerId)
                .orElseThrow(() -> new IllegalArgumentException("Employer not found"));
        return applicationRepository.findByEmployer(employer);
    }

    public void updateApplicationStatus(Long applicationId, String status) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new InvalidApplicationException("Application not found with id: " + applicationId));

        try {
            // Convert status to enum
            application.setStatus(ApplicationStatus.valueOf(status.toUpperCase()));
        } catch (IllegalArgumentException e) {
            throw new InvalidApplicationException("Invalid status value: " + status);
        }

        applicationRepository.save(application);
    }
    public List<Application> getApplicationsForEmployer(Employer employer) {
        // Assuming you have an ApplicationRepository that allows you to find applications by employer
        return applicationRepository.findByEmployer(employer);
    }
    public List<Job> getJobsForEmployer(Employer employer) {
        // Assuming you have a JobRepository that allows you to find jobs by employer
        return jobRepository.findByEmployer(employer);
    }

    public Application getApplicationById(Long applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new InvalidApplicationException("Application not found with id: " + applicationId));
    }


	

}
