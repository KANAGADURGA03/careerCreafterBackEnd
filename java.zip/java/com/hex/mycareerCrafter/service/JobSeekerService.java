package com.hex.mycareerCrafter.service;

import java.time.LocalDateTime;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hex.mycareerCrafter.models.ApplicationStatus;
import com.hex.mycareerCrafter.models.Employer;
import com.hex.mycareerCrafter.exceptions.InvalidApplicationException;
import com.hex.mycareerCrafter.exceptions.UserNotFoundException;
import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.models.JobSeeker;
import com.hex.mycareerCrafter.payload.ApplicationDTO;
import com.hex.mycareerCrafter.payload.ApplicationStatusResponse;
import com.hex.mycareerCrafter.payload.JobSeekerDTO;
import com.hex.mycareerCrafter.repository.ApplicationRepository;
import com.hex.mycareerCrafter.repository.EmployerRepository;
import com.hex.mycareerCrafter.repository.JobRepository;
import com.hex.mycareerCrafter.repository.JobSeekerRepository;

@Service
@Transactional
public class JobSeekerService {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ModelMapper modelMapper;
    
    @Autowired
    private EmployerRepository employerRepository;

    // Method to view all job listings
    public List<Job> viewJobListings() {
        return jobRepository.findAll();
    }

    public Application applyForJob(Long jobId, Long jobSeekerId, ApplicationDTO applicationDTO) {
        // Check if jobSeekerId and employerId are null
        if (jobSeekerId == null) {
            throw new IllegalArgumentException("Job Seeker ID must not be null");
        }
        
        if (applicationDTO.getEmployerId() == null) {
            throw new IllegalArgumentException("Employer ID must not be null");
        }

        // Fetch the existing Job entity
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new InvalidApplicationException("Job not found with id: " + jobId));

        // Fetch the existing JobSeeker entity
        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new UserNotFoundException("Job Seeker not found with id: " + jobSeekerId));

        // Fetch the existing Employer entity
        Employer employer = employerRepository.findById(applicationDTO.getEmployerId())
                .orElseThrow(() -> new UserNotFoundException("Employer not found with id: " + applicationDTO.getEmployerId()));

        // Create a new Application instance
        Application application = new Application();

        // Set properties from ApplicationDTO to Application
        application.setJob(job); // Use the fetched Job entity
        application.setJobSeeker(jobSeeker); // Use the fetched JobSeeker entity
        application.setEmployer(employer); // Use the fetched Employer entity
        application.setResume(applicationDTO.getResume()); // The resume is saved as base64

        // Convert status from String to ApplicationStatus enum with default value
        String statusString = applicationDTO.getStatus();
        ApplicationStatus status = (statusString != null && !statusString.isEmpty())
                ? ApplicationStatus.valueOf(statusString.toUpperCase()) // Convert to ApplicationStatus enum
                : ApplicationStatus.PENDING; // Default to PENDING if not provided

        application.setStatus(status); // Set the status as ApplicationStatus enum
        application.setDate(LocalDateTime.now()); // Set the current date/time
        application.setQualification(applicationDTO.getQualification());
        application.setTwelfthPercentage(applicationDTO.getTwelfthPercentage());

        // Save the application entity
        return applicationRepository.save(application);
    }

    public ApplicationStatusResponse viewApplicationStatus(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new InvalidApplicationException("Application not found with id: " + applicationId));
        
        // Create a response object
        ApplicationStatusResponse response = new ApplicationStatusResponse();
        response.setApplicationId(application.getApplicationId());
        response.setStatus(application.getStatus().name());
        return response;
    }

    public JobSeeker createJobSeeker(JobSeekerDTO jobSeekerDTO) {
        JobSeeker jobSeeker = modelMapper.map(jobSeekerDTO, JobSeeker.class);
        return jobSeekerRepository.save(jobSeeker);
    }

    public JobSeeker updateJobSeeker(Long jobSeekerId, JobSeekerDTO jobSeekerDTO) {
        JobSeeker existingJobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new UserNotFoundException("Job Seeker not found with id: " + jobSeekerId));
        // Update fields as needed
        existingJobSeeker.setName(jobSeekerDTO.getName());
        existingJobSeeker.setEmail(jobSeekerDTO.getEmail());
        // ... update other fields
        return jobSeekerRepository.save(existingJobSeeker);
    }

    public void deleteJobSeeker(Long jobSeekerId) {
        JobSeeker existingJobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new UserNotFoundException("Job Seeker not found with id: " + jobSeekerId));
        jobSeekerRepository.delete(existingJobSeeker);
    }

    public JobSeeker getJobSeekerById(Long jobSeekerId) {
        return jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new UserNotFoundException("Job Seeker not found with id: " + jobSeekerId));
    }
    public Job getJobById(Long jobId) {
        return jobRepository.findById(jobId)
                .orElseThrow(() -> new InvalidApplicationException("Job not found with id: " + jobId));
    }
    
    // New method to get all applications for a job seeker
    public List<ApplicationStatusResponse> getAllApplicationsForJobSeeker(Long jobSeekerId) {
        // Fetch applications from the repository
        List<Application> applications = applicationRepository.findByJobSeekerId(jobSeekerId);
        
        // Convert Application entities to ApplicationStatusResponse DTOs (implement this conversion logic as needed)
        return applications.stream()
            .map(this::convertToApplicationStatusResponse)
            .toList();
    }
 // Method to convert Application entity to ApplicationStatusResponse DTO
    private ApplicationStatusResponse convertToApplicationStatusResponse(Application application) {
        ApplicationStatusResponse response = new ApplicationStatusResponse();
        response.setApplicationId(application.getApplicationId());
        response.setStatus(application.getStatus() != null ? application.getStatus().name() : null);        
        // Retrieve the jobId from the associated Job entity
        if (application.getJob() != null) {
            response.setJobId(application.getJob().getJobId()); // Access jobId from the Job entity
        } else {
            response.setJobId(null); // Or handle the case where the Job is null as needed
        }
        
        // Set other fields as necessary
        return response;
    }


	public void saveJob(Long jobSeekerId, Job job) {
	    // Check if the job seeker exists
	    JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
	            .orElseThrow(() -> new UserNotFoundException("Job Seeker not found with id: " + jobSeekerId));

	    // Assuming there's a field in JobSeeker to hold saved jobs
	    jobSeeker.getSavedJobs().add(job); // Ensure to manage bidirectional relationships properly

	    // Save the updated JobSeeker entity
	    jobSeekerRepository.save(jobSeeker);
	}
	
	
	



}
