package com.hex.mycareerCrafter.models;
public enum UserRole {
    EMPLOYER,
    JOB_SEEKER
}