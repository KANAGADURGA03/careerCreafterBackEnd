package com.hex.mycareerCrafter.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference; // Import this for JsonBackReference
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;

@Entity
@DiscriminatorValue("JOB_SEEKER")
public class JobSeeker extends User {

    @Column(name = "seeker_id", unique = true, nullable = true)
    private Long seekerId;  // Optional ID to differentiate job seekers

    private String qualification;

    @OneToMany(mappedBy = "jobSeeker", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "seeker-applications") // Same name as in Application
    private List<Application> applications;
    
    @OneToMany(mappedBy = "jobSeeker", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference(value = "jobSeeker-jobs")
    private List<Job> savedJobs;
    
    
   

  
	public List<Job> getSavedJobs() {
		return savedJobs;
	}

	
	public void setSavedJobs(List<Job> savedJobs) {
		this.savedJobs = savedJobs;
	}

	// Getters and setters
    public Long getSeekerId() {
        return seekerId;
    }

	public void setSeekerId(Long seekerId) {
        this.seekerId = seekerId;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public List<Application> getApplications() {
        return applications;
    }

    public void setApplications(List<Application> applications) {
        this.applications = applications;
    }

    // This method returns the JobSeeker ID (inherited from User class)
    public Long getJobSeekerId() {
        return getId(); // Assuming getId() is the method in the User class that returns the user ID
    }
}
