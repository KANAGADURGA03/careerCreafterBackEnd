package com.hex.mycareerCrafter.models;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

@Entity

public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    @ManyToOne
    @JoinColumn(name = "job_id", nullable = false)
    @JsonBackReference(value = "job-applications") // Assign a unique name
    private Job job;

    @ManyToOne
    @JoinColumn(name = "seeker_id", nullable = false)
    @JsonBackReference(value = "seeker-applications") // Assign a unique name
    private JobSeeker jobSeeker;

    @ManyToOne
    @JoinColumn(name = "employer_id", nullable = false)
    @JsonBackReference(value = "employer-applications") // Assign a unique name
    private Employer employer;
    
    @Lob
    @Column(name = "resume", nullable = false)
    private byte[] resume;

    @Enumerated(EnumType.STRING)
    private ApplicationStatus status;

    private LocalDateTime date;

    private String qualification;

    @Column(name = "twelfth_percentage", nullable = false)
    private Double twelfthPercentage;

    // Getters and setters
    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public JobSeeker getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(JobSeeker jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

//    public String getResume() {
//        return resume;
//    }
//
//    public void setResume(String resume) {
//        this.resume = resume;
//    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public byte[] getResume() {
		return resume;
	}

	public void setResume(byte[] resume) {
		this.resume = resume;
	}

	public void setStatus(ApplicationStatus status) {
        this.status = status;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public Double getTwelfthPercentage() {
        return twelfthPercentage;
    }

    public void setTwelfthPercentage(Double twelfthPercentage) {
        this.twelfthPercentage = twelfthPercentage;
    }

    public Employer getEmployer() {
        return employer;
    }

    public void setEmployer(Employer employer) {
        this.employer = employer;
    }
}
