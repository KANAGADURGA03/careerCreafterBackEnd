package com.hex.mycareerCrafter.models;

import jakarta.persistence.*;

@Entity
@DiscriminatorValue("EMPLOYER")
public class Employer extends User {
	

    // Optional ID to differentiate employers

    private String companyName;

    // Getters and setters
    

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

	

	
}
