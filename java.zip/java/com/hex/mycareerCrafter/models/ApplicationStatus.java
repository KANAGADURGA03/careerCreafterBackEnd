package com.hex.mycareerCrafter.models;
public enum ApplicationStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}