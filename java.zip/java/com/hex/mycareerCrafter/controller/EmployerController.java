package com.hex.mycareerCrafter.controller;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hex.mycareerCrafter.exceptions.UserNotFoundException;
import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.Employer;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.payload.ApplicationDTO;
import com.hex.mycareerCrafter.payload.JobDTO;
import com.hex.mycareerCrafter.service.EmployerService;

@RestController
@RequestMapping("/api/employers")
@CrossOrigin("http://localhost:3000")
public class EmployerController {

    @Autowired
    private EmployerService employerService;

    @Autowired
    private ModelMapper modelMapper;

    
    @GetMapping("/{id}")
    public ResponseEntity<Employer> getEmployerById(@PathVariable("id") Long employerId) {
        try {
            Employer employer = employerService.getEmployerById(employerId);
            return new ResponseEntity<>(employer, HttpStatus.OK);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace for debugging
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Create Job
   
  
//    @PostMapping("/{employerId}/jobs")
//    public ResponseEntity<JobDTO> createJob(@PathVariable Long employerId, @RequestBody JobDTO jobDTO) {
//        // Map the JobDTO to Job entity
//        Job job = modelMapper.map(jobDTO, Job.class);
//        
//        // Call the service to create the job and associate it with the employer
//        Job createdJob = employerService.createJob(employerId, job);
//        
//        // Map the created Job entity back to JobDTO
//        JobDTO createdJobDTO = modelMapper.map(createdJob, JobDTO.class);
//        
//        // Return the response with the created job details
//        return new ResponseEntity<>(createdJobDTO, HttpStatus.CREATED);
//    }
    
    @PostMapping("/{employerId}/jobs")
    public ResponseEntity<JobDTO> createJob(@PathVariable Long employerId, @RequestBody JobDTO jobDTO) {
        // Fetch employer by ID
        Employer employer = employerService.getEmployerById(employerId);
        if (employer == null) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND); // Employer not found
        }

        Job job = modelMapper.map(jobDTO, Job.class);
        job.setEmployer(employer); // Set the employer in Job

        Job createdJob = employerService.createJob(employerId, job); // Save job
        JobDTO createdJobDTO = modelMapper.map(createdJob, JobDTO.class);

        return new ResponseEntity<>(createdJobDTO, HttpStatus.CREATED);
    }



    // Update Job
    @PutMapping("/jobs/{jobId}")
    public ResponseEntity<JobDTO> updateJob(@PathVariable Long jobId, @RequestBody JobDTO jobDTO) {
        Job jobDetails = modelMapper.map(jobDTO, Job.class);
        Job updatedJob = employerService.updateJob(jobId, jobDetails);
        JobDTO updatedJobDTO = modelMapper.map(updatedJob, JobDTO.class);
        return new ResponseEntity<>(updatedJobDTO, HttpStatus.OK);
    }


    // Delete Job (with deletion confirmation message)
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<String> deleteJob(@PathVariable Long jobId) {
        employerService.deleteJob(jobId);
        return new ResponseEntity<>("Job deleted successfully.", HttpStatus.OK);
    }

    // Update Application Status
 // Update Application Status
    @PatchMapping("/applications/{applicationId}/status")
    public ResponseEntity<String> updateApplicationStatus(
        @PathVariable Long applicationId, 
        @RequestParam String status) {
        employerService.updateApplicationStatus(applicationId, status);
        return new ResponseEntity<>("Status updated successfully.", HttpStatus.OK);
    }
    @GetMapping("/{employerId}/applications")
    public ResponseEntity<List<ApplicationDTO>> getApplicationsForEmployer(@PathVariable Long employerId) {
        // Fetch the Employer entity using employerId
        Employer employer = employerService.getEmployerById(employerId); // Ensure you have this method in your service

        // Retrieve applications for the given Employer
        List<Application> applications = employerService.getApplicationsForEmployer(employer);

        // Log the applications retrieved
        System.out.println("Applications for employer ID " + employerId + ": " + applications);

        // Map Application entities to ApplicationDTOs
        List<ApplicationDTO> applicationDTOs = applications.stream()
            .map(application -> modelMapper.map(application, ApplicationDTO.class))
            .collect(Collectors.toList());

        // Log the returned application DTOs
        System.out.println("Returned application DTOs: " + applicationDTOs);
        return new ResponseEntity<>(applicationDTOs, HttpStatus.OK);
    }

    @GetMapping("/{employerId}/jobs")
    public ResponseEntity<List<JobDTO>> getJobsForEmployer(@PathVariable Long employerId) {
        // Fetch the Employer entity using employerId
        Employer employer = employerService.getEmployerById(employerId);  // Ensure this method exists in your service
        
        // Retrieve the list of jobs for the given Employer
        List<Job> jobs = employerService.getJobsForEmployer(employer);

        // Log the jobs retrieved
        System.out.println("Jobs for employer ID " + employerId + ": " + jobs);

        // Map Job entities to JobDTOs using ModelMapper
        List<JobDTO> jobDTOs = jobs.stream()
            .map(job -> modelMapper.map(job, JobDTO.class))
            .collect(Collectors.toList());

        // Log the returned job DTOs
        System.out.println("Returned job DTOs: " + jobDTOs);
        
        // Return the list of job DTOs with OK status
        return new ResponseEntity<>(jobDTOs, HttpStatus.OK);
    }
    
//    @GetMapping("/applications/{applicationId}/resume")
//    public ResponseEntity<byte[]> getResume(@PathVariable Long applicationId) {
//        try {
//            Application application = employerService.getApplicationById(applicationId);
//            byte[] resume = application.getResume();
//            
//            if (resume == null) {
//                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Resume not found
//            }
//            
//            return ResponseEntity.ok()
//                    .header("Content-Type", "application/pdf") // Change the content type as necessary
//                    .body(resume);
//        } catch (Exception e) {
//            e.printStackTrace(); // Print the stack trace for debugging
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
    @GetMapping("/applications/{applicationId}/resume")
    public ResponseEntity<byte[]> getResume(@PathVariable Long applicationId) {
        try {
            Application application = employerService.getApplicationById(applicationId);
            byte[] resume = application != null ? application.getResume() : null;

            if (resume == null || resume.length == 0) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Resume not found or empty
            }

            System.out.println("Resume byte array length: " + resume.length); // Debug: log byte array length
            
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"resume.pdf\"")
                    .header("Content-Type", "application/pdf")
                    .body(resume);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }




}