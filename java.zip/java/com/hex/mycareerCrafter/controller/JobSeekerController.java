package com.hex.mycareerCrafter.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hex.mycareerCrafter.exceptions.InvalidApplicationException;
import com.hex.mycareerCrafter.exceptions.UserNotFoundException;
import com.hex.mycareerCrafter.models.Application;
import com.hex.mycareerCrafter.models.Job;
import com.hex.mycareerCrafter.models.JobSeeker;
import com.hex.mycareerCrafter.payload.ApplicationDTO;
import com.hex.mycareerCrafter.payload.ApplicationResponse;
import com.hex.mycareerCrafter.payload.ApplicationStatusResponse;
import com.hex.mycareerCrafter.payload.JobDTO;
import com.hex.mycareerCrafter.payload.JobSeekerDTO;
import com.hex.mycareerCrafter.service.JobSeekerService;

@RestController
@RequestMapping("/api/job-seekers")
@CrossOrigin(origins = "http://localhost:3000")
public class JobSeekerController {

	@Autowired
	private JobSeekerService jobSeekerService;

	@Autowired
	private ModelMapper modelMapper;

	// Get all job listings
	@GetMapping("/jobs")
    public ResponseEntity<List<JobDTO>> viewJobListings() {
        List<Job> jobListings = jobSeekerService.viewJobListings();
        // Convert List<Job> to List<JobDTO>
        List<JobDTO> jobDTOs = jobListings.stream()
                                          .map(job -> modelMapper.map(job, JobDTO.class))
                                          .collect(Collectors.toList());
        return new ResponseEntity<>(jobDTOs, HttpStatus.OK);
    }



	@PostMapping("/{jobSeekerId}/apply/{jobId}")
	public ResponseEntity<ApplicationResponse> applyForJob(
	        @PathVariable Long jobId,
	        @PathVariable Long jobSeekerId,
	        @RequestParam("resume") MultipartFile resume,
	        @RequestParam("qualification") String qualification,
	        @RequestParam("twelfthPercentage") Double twelfthPercentage) {
	    
	    // Convert the MultipartFile to byte array
	    byte[] resumeBytes;
	    try {
	        resumeBytes = resume.getBytes();
	    } catch (IOException e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApplicationResponse(null, "Failed to process resume"));
	    }

	    // Retrieve job to get employerId
	    Job job = jobSeekerService.getJobById(jobId);
	    
	    if (job == null) {
	    	
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApplicationResponse(null, "Job not found"));
	    }
	    JobDTO jobDTO = new JobDTO();
        jobDTO.setJobId(job.getJobId()); // Assuming getId() returns the job ID
        jobDTO.setTitle(job.getTitle());
        jobDTO.setDescription(job.getDescription());
        jobDTO.setQualification(job.getQualification());
        jobDTO.setEmployerId(job.getEmployer().getId()); // Assuming Employer has a getId() method

       // return ResponseEntity.ok(jobDTO); // Return job details in response
	    Long employerId = jobDTO.getEmployerId(); // Assuming `getEmployerId()` returns the employer ID from the Job entity

	    // Create ApplicationDTO object
	    ApplicationDTO applicationDTO = new ApplicationDTO();
	    applicationDTO.setJobId(jobId);
	    applicationDTO.setJobSeekerId(jobSeekerId);
	    applicationDTO.setResume(resumeBytes);
	    applicationDTO.setQualification(qualification);
	    applicationDTO.setTwelfthPercentage(twelfthPercentage);
	    applicationDTO.setEmployerId(employerId); // Set employerId in ApplicationDTO

	    Application application = jobSeekerService.applyForJob(jobId, jobSeekerId, applicationDTO);
	    ApplicationResponse response = new ApplicationResponse(application.getApplicationId(), 
	                                                            "Application successfully submitted.");
	    return new ResponseEntity<>(response, HttpStatus.CREATED);
	}




	// View application status by application ID
	@GetMapping("/applications/{applicationId}")
	public ResponseEntity<ApplicationStatusResponse> viewApplicationStatus(@PathVariable Long applicationId) {
	    ApplicationStatusResponse response = jobSeekerService.viewApplicationStatus(applicationId);
	    return new ResponseEntity<>(response, HttpStatus.OK);
	}


	// Create a new job seeker
	@PostMapping
	public ResponseEntity<JobSeeker> createJobSeeker(@Validated @RequestBody JobSeekerDTO jobSeekerDTO) {
		JobSeeker createdJobSeeker = jobSeekerService.createJobSeeker(jobSeekerDTO);
		return new ResponseEntity<>(createdJobSeeker, HttpStatus.CREATED);
	}

	// Update an existing job seeker
	@PutMapping("/{jobSeekerId}")
	public ResponseEntity<JobSeeker> updateJobSeeker(@PathVariable Long jobSeekerId,
			@Validated @RequestBody JobSeekerDTO jobSeekerDTO) {
		JobSeeker updatedJobSeeker = jobSeekerService.updateJobSeeker(jobSeekerId, jobSeekerDTO);
		return new ResponseEntity<>(updatedJobSeeker, HttpStatus.OK);
	}

	// Delete an existing job seeker
	@DeleteMapping("/{jobSeekerId}")
	public ResponseEntity<String> deleteJobSeeker(@PathVariable Long jobSeekerId) {
		jobSeekerService.deleteJobSeeker(jobSeekerId);
		return new ResponseEntity<>("Job Seeker deleted successfully.", HttpStatus.OK);
	}
	   // Get job seeker by ID
    @GetMapping("/{id}")
    public ResponseEntity<JobSeeker> getJobSeekerById(@PathVariable("id") Long jobSeekerId) {
        try {
            JobSeeker jobSeeker = jobSeekerService.getJobSeekerById(jobSeekerId);
            return new ResponseEntity<>(jobSeeker, HttpStatus.OK);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace for debugging
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    //New method to get all applications for a job seeker
    @GetMapping("/{jobSeekerId}/applications")
    public ResponseEntity<List<ApplicationStatusResponse>> getAllApplicationsForJobSeeker(@PathVariable Long jobSeekerId) {
        List<ApplicationStatusResponse> applications = jobSeekerService.getAllApplicationsForJobSeeker(jobSeekerId);
        return new ResponseEntity<>(applications, HttpStatus.OK);
    }
    
    @PostMapping("/{jobSeekerId}/savedJobs")
    public ResponseEntity<String> saveJob(@PathVariable Long jobSeekerId, @RequestBody Job job) {
        try {
            jobSeekerService.saveJob(jobSeekerId, job);
            return new ResponseEntity<>("Job saved successfully.", HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving job: " + e.getMessage());
        }
    }
    
    
    

    


}